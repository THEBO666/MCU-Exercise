sbit RELAY=P1^3;
sbit BEEP=P1^5;
void Beep(unsigned char ena);
void Relay(unsigned char ena);