void Uart_SendByte(char dat);
void Uart_SendString(char *dat);
void UartInit(void);